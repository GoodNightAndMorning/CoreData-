//
//  Employee.h
//  CoreData基本使用
//
//  Created by zsx on 2017/11/25.
//  Copyright © 2017年 zsx. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
@interface Employee : NSManagedObjectModel
@property(nonatomic,strong)NSString *name;
@property(nonatomic,assign)float height;
@end
