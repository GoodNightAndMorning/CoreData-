//
//  ViewController.m
//  CoreData基本使用
//
//  Created by zsx on 2017/11/25.
//  Copyright © 2017年 zsx. All rights reserved.
//

#import "ViewController.h"
#import <CoreData/CoreData.h>
#import "Employee.h"
@interface ViewController ()
{
    NSManagedObjectContext *_context;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //1.创建模型文件，相当于数据库的表
    //2.创建实体类（注意：在xcode8.1前需要添加实体）
    //3.生成上下午，关联模型文件生成的数据库
    
    NSManagedObjectContext *context = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    _context = context;
    //持久化存储协调器：调度器
    //将数据从内存移到硬盘
    
    //模型文件
    NSManagedObjectModel *model = [NSManagedObjectModel mergedModelFromBundles:nil];//nil 表示默认mainBoundle
    //调度器
    NSPersistentStoreCoordinator *store = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:model];
    
    //告诉cordata 数据库的文件名字和路径
    NSString *doc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString *componyPath = [doc stringByAppendingPathComponent:@"compony.db"];
    
    [store addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:[NSURL fileURLWithPath:componyPath] options:nil error:nil];
    
    context.persistentStoreCoordinator = store;
    
    NSLog(@"%@",componyPath);
}
-(void)addEmployee{
    Employee *employee = (Employee *)[NSEntityDescription insertNewObjectForEntityForName:@"Person" inManagedObjectContext:_context];
    employee.name = @"王五";
    employee.height = 1.80;
    
    NSError *error = nil;
    [_context save:&error];
    if (error) {
        NSLog(@"%@",error);
    }
}
-(void)checkEmployee{
    //1.抓取请求对象
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"Person"];
    //设置过滤条件，不设置默认查全部表
//    NSPredicate *pre = [NSPredicate predicateWithFormat:@"name= %@",@"张三"];
//    request.predicate = pre;
    //设置排序
    NSSortDescriptor * sort = [NSSortDescriptor sortDescriptorWithKey:@"height" ascending:YES];
    request.sortDescriptors = @[sort];
    //执行请求
    NSError *error = nil;
    NSArray *emps = [_context executeFetchRequest:request error:&error];
    if (error) {
        NSLog(@"%@",error);
    }
    NSLog(@"%@",emps);
    for (Employee *model in emps) {
        NSLog(@"name:%@,height:%f",model.name,model.height);
    }
}
-(void)deleteEmployee{
    /**
     1.查询到要删除的内容
     2.获取输入的内容
     */
    NSString * deleteContent = @"张三";
    
    /** 查询要删除带有输入的关键字的对象 */
    NSPredicate * pre = [NSPredicate predicateWithFormat:@"name= %@",deleteContent];
    
    /** 根据上下文获取查询数据库实体的请求参数---要查询的entity(实体) */
    NSEntityDescription * des = [NSEntityDescription entityForName:@"Person" inManagedObjectContext:_context];
    
    /** 查询请求 */
    NSFetchRequest * request = [NSFetchRequest new];
    
    /** 根据参数获取查询内容 */
    request.entity = des;
    
    request.predicate = pre;
    
    /**
     1.获取所有被管理对象的实体---根据查询请求取出实体内容
     2.获取的查询内容是数组
     3.删掉所有查询到的内容
     3.1.这里是模糊查询 即 删除包含要查询内容的字母的内容
     */
    NSArray * array = [_context executeFetchRequest:request error:NULL];
    
    /** 对查询的内容进行操作 */
    for (Employee * p in array) {
        [_context deleteObject:p];
    }
    NSLog(@"删除完成");
    NSError *error = nil;
    [_context save:&error];
    if (error) {
        NSLog(@"%@",error);
    }
}
-(void)changeEmployee{
    /** 获取输入内容 */
    NSString * updateContent = @"李四";
    NSPredicate * pre = [NSPredicate predicateWithFormat:@"name= %@",updateContent];
    
    NSEntityDescription * des = [NSEntityDescription entityForName:@"Person" inManagedObjectContext:_context];
    NSFetchRequest * request = [NSFetchRequest new];
    request.entity = des;
    request.predicate = pre;
    
    NSArray * array = [_context executeFetchRequest:request error:NULL];
    
    //这里修改的话把全部查询到的内容修改成了 "张三",可以根据自己的需要进行设置
    for (Employee *p in array) {
        p.height = 2.0;
        [_context updatedObjects];
    }
    NSLog(@"修改完成");
    [_context save:NULL];
}
- (IBAction)addAction:(id)sender {
    [self addEmployee];
}
- (IBAction)deleteAction:(id)sender {
    [self deleteEmployee];
}
- (IBAction)changeAction:(id)sender {
    [self changeEmployee];
}
- (IBAction)checkAction:(id)sender {
    [self checkEmployee];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
